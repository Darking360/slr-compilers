import { Rule } from '../rule/rule';

export class Closing {
  reglas: Rule[] = [];
  isCopy: boolean = false;
  index: number;
  from: string;
  to: string;
  isFinal: boolean = false;

  isACopy = (): boolean => {
  	return this.isCopy;
  }

}


